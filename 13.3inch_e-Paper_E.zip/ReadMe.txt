中文：
使用方法详见中文Wiki
https://www.waveshare.net/wiki/13.3inch_e-Paper_HAT%2B_(E)

English：
See the English Wiki for details
https://www.waveshare.com/wiki/13.3inch_e-Paper_HAT%2B_(E)