#ifndef _TEST_H_
#define _TEST_H_

#include <stdlib.h>     //exit()
#include <signal.h>     //signal()
#include <time.h>
#include "ImageData.h"
#include "GUI_Paint.h"
#include "GUI_BMPfile.h"

int EPD_13in3e_test(void);
#endif